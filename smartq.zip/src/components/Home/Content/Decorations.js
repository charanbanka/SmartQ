import React from 'react'

const Decorations = () => {
  return (
    <div>Decorations</div>
  )
}

export default Decorations