import React from 'react'

const Pizza = () => {
  return (
    <div>Pizza</div>
  )
}

export default Pizza